var app = 'app';

console.log(app);
